<?php
  $page_title = "Exercices – JRPG Prépa";
  require __DIR__ . "/includes/head.php";
?>
<h1 class="h4 mb-3">Exercices (démo)</h1>
<ul>
  <li>Modèles algébriques</li>
  <li>Proportionnalité</li>
  <li>Descente (réservoirs, batteries, etc.)</li>
</ul>
<p class="text-muted">À brancher avec ta base de données et l'éditeur auteur/admin plus tard.</p>
<?php require __DIR__ . "/includes/footer.php"; ?>
