// App JS (placeholder)
console.log('JRPG minimal UI loaded');
